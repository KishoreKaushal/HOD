module HOD.Ensemble.IForest where

sayHello :: IO ()
sayHello = do
    putStrLn "hello world"
